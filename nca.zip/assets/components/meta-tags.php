
  <meta charset="utf-8">
  <meta charset="UTF-8">
  <title><?php echo $title; ?> Need Class Assistance | Need Online Help </title>
  <meta name="google-site-verification" content="fxzA_ShfvX8keaog1I59ButCtaQalcryGMy4kfY-DVk" />
  <meta name="description" content="<?php echo $description; ?>">
  <meta name="keywords" content="<?php echo $keywords; ?>">
  <meta name="author" content="<?php echo $author; ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- COMMON TAGS -->
    <!-- Search Engine -->
    <meta name="image" content="https://needclassassistance.com/assets/img/logo.png">
    <!-- Schema.org for Google -->
    <meta itemprop="name" content="Need Class Assistance | Online Assistance | Online Helper">
    <meta itemprop="description" content="Need Class Assistance.com (NCA) is a place that caters to all of your educational needs. We aim to provide you the best of services without any hustle.">
    <meta itemprop="image" content="https://needclassassistance.com/assets/img/logo.png">
    <link rel="canonical" href="https://needclassassistance.com/"/> 
  <link rel="alternate" href="https://needclassassistance.com/" hreflang="en-us" />

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon"> 

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MBX9R5K');</script>
<!-- End Google Tag Manager -->

  