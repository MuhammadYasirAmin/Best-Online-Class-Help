 <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MBX9R5K"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

 <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <a href="http://needclassassistance.com" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="active" href="index">Home</a></li>
          <li><a href="about">About</a></li>
          <li class="dropdown"><a href="#"><span>Our Services</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="cater-online-classes">We Tutor Online Class</a></li>
              <li><a href="exam-help">We Do Online Exam Tutoring</a></li>
              <li><a href="quizzes">Tutoring For Quizzes And Assignment</a></li>
            </ul>
          </li>
          <li><a href="courses">Courses</a></li>
          <li><a href="trainers">Our Experts</a></li>
         
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="contact" class="get-started-btn">Contact Us</a>

    </div>
  </header><!-- End Header -->