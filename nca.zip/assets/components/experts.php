<section id="trainers" class="trainers">
      <div class="container" data-aos="fade-up">
<div class="section-title">
          <!--<h2>Our Expert</h2>-->
          <p>Our Experts</p>
        </div> 
        <div class="row" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/trainers/trainer-2.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h4>William</h4>
                <span>Web Development</span>
                <p>
                  Mr William is a very humble soul who has spent most of years teaching in some of the top institutions. His academic expertise have helped shaped the future of many young aspirants 
                </p>
                
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/trainers/trainer-1.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h4>Olivia Jackson</h4>
                <span>Marketing</span>
                <p>
                  Mrs. Olivia Jackson begun her teaching career at a very young age and has come a long way, her practical implementation of the (subject) has created an everlasting impact in the field.
                </p>
                
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="member">
              <img src="assets/img/trainers/trainer-3.jpg" class="img-fluid" alt="">
              <div class="member-content">
                <h4>Noah Smith</h4>
                <span>Content</span>
                <p>
                  Dr. Noah Smith has been serving as an academician in top institutions for the last 15 years. His firm hold of the subject is commendable as he has also been conducting webinars and online counselling sessions for the last few years as well.
                </p>
                
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>