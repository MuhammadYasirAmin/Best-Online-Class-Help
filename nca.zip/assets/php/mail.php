<?php
                
                if (isset($_POST['leads_sbmit_btn'])) {
                		$host = "localhost";
                		$username="u782400943_assistant";
                		$password="Qwerty123";
                		$db = "u782400943_need_assistanc";
                
                		$connect = new mysqli($host, $username, $password, $db);
                		if ($connect->connect_error) {
                				die("Connection failed: " . $connect->connect_error);
                		}
                
                		$cname = $_POST['Lead_Name'];
                		$email = $_POST['Lead_Email'];
                		$num = $_POST['Lead_Phone'];
                		$sub = $_POST['Lead_Subject'];
                		$msg = $_POST['Lead_Message'];
                
                		$sql = "INSERT INTO `Leads_table` (Name, Email, Phone, Subject, Message) VALUES ('".$cname."', '".$email."', '".$num."', '".$sub."', '".$msg."')";
                		if (mysqli_query($connect, $sql)) {
                			mysqli_close($connect);
                			
                				$hosta = "localhost";
                				$usernamea="u782400943_CRM_User";
                				$passworda="+P8yl:MmA2o";
                				$dba = "u782400943_Cruiser_CRM";
                
                				$connecta = new mysqli($hosta, $usernamea, $passworda, $dba);
                				if ($connecta->connect_error) {
                						die("Connection failed: " . $connecta->connect_error);
                				}
                						date_default_timezone_set("Asia/Karachi");
                							$date = date('F j, Y, g:i a');
                							$username = "From Google";
                
                							$lead_number = 0;
                							$lead_Numb = "";
                							$abbr = "NCA";
                
                							$array = array();
                							$querya = "SELECT * FROM Lead_OCG ORDER BY ID DESC LIMIT 1";
                							$resulta = mysqli_query($connecta, $querya);
                							while ($row = mysqli_fetch_array($resulta)){
                									$array[] = $row;
                							}
                							$lead_number = $array[0]['Lead_numb'];
                
                							if (empty($lead_number)) {
                									$lead_number = 1000;
                									$lead_Numb = $abbr.'-'.$lead_number;
                							}else {
                									$lead_number = $lead_number + 1;
                									$lead_Numb = $abbr.'-'.$lead_number;
                								}
                
                
                							$client_name = $_POST['Lead_Name'];
                							$client_phone = $_POST['Lead_Phone'];
                							$client_email = $_POST['Lead_Email'];
                							$brand_select = "Need Class Assistance";
                							$team_select = "From PPC";
                							$description = $_POST['Lead_Message'];
                
                							$queryaa = "INSERT INTO `Lead_OCG` (Lead_Code, Client_Name, Email_address, Phone_Number, website, Team, description, Created_at, Created_by, Lead_numb) VALUES
                																		('$lead_Numb', '$client_name', '$client_email', '$client_phone', '$brand_select', '$team_select', '$description', '$date', '$username', '$lead_number')";
                
                							if (mysqli_query($connecta, $queryaa)) {
                								$flag=true;
                                            		$url = "https://cruiserstech.com/api_index.php";
                                                $client = curl_init($url);
                                                $form_data = array(
                                                  'name'  => $cname,
                                                  'email'  => $email,
                                                  'number'  => $num,
                                                  'website_id'=>"1"
                                                );
                                                curl_setopt($client, CURLOPT_POST, true);
                                                curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
                                                curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
                                            	$response = curl_exec($client);
                                            
                                                                curl_close($client);
                                            
                                            
                                                                $name = $_POST['Lead_Name'];
                                                                $email = $_POST['Lead_Email'];
                                                                $numb = $_POST['Lead_Phone'];
                                                                $message = $_POST['Lead_Message'];
                                                                header('Content-Type: application/json');
                                            
                                                                $content="From: $name \nEmail: $email \nContact: $numb \nMessage: $message \n\nInformation Get From Banner Form";
                                                                $recipient = "info@needclassassistance.com";
                                                                $mailheader = "From: $email \r\n";
                                                                mail($recipient, $subject, $content, $mailheader) or die("Error!");
                								header("location: /ASAP-Contact-You.php");
                                                exit();
                							}
                							else {
                								// $flag=false;
                								echo "ERROR: Could not able to executee" .$queryaa. " " . mysqli_error($connecta);
                								header("location: /index.html?error=Lead-Not-Submitted");
                                                exit();
                							}
                		} else {
                			echo "ERROR: Could not able to execute " .$sql. "<br>" . mysqli_error($connect);
                		}
                
            
                	} else {
                		header("location: /index.php?error=Not-Clicked");
                        exit();
                	}      
?>